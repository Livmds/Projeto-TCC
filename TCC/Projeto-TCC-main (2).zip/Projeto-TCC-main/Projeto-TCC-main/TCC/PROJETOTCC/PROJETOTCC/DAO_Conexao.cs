﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROJETOTCC
{
    class DAO_Conexao
    {
        private static MySqlConnection con;

        public static Boolean getConexao(String local, String banco, String user, String senha)
        {
            Boolean retorno = false;
            try
            {
                con = new MySqlConnection("server=" + local + ";User ID=" + user + ";database=" + banco + ";password=" + senha);
                con.Open();
                retorno = true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return retorno;

        }

        public static Boolean CadAdotante(String Nome, int CPF, int Contato, String Endereço, int Num, String Estado, String Cidade)
        {
            Boolean cadAdo = false;
            try
            {
                con.Open();
                MySqlCommand cadAdotante = new MySqlCommand("insert into CadAdotante (CPF, Nome, Endereço, Num, Cidade, Estado, Contato) values('" + CPF + "','" + Nome + "'," + Endereço + "','" + Num + "','" + Cidade + "','" + Estado + "'," + Contato+")" ,con);
                cadAdotante.ExecuteNonQuery();
                cadAdo = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                con.Close();
            }
            return cadAdo;
        }
    }
}
