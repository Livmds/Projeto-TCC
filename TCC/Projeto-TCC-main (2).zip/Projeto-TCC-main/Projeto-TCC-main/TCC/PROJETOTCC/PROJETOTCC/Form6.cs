﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROJETOTCC
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text == "")
            {
                MessageBox.Show("Preencha todos os campos!");
            }else if(textBox2.Text == "")
            {
                MessageBox.Show("Preencha todos os campos!");
            }else if(textBox3.Text == "")
            {
                MessageBox.Show("Preencha todos os campos!");
            }else if(textBox4.Text == "")
            {
                MessageBox.Show("Preencha todos os campos!");
            }
            else if (textBox5.Text == "")
            {
                MessageBox.Show("Preencha todos os campos!");
            }
            else if (maskedTextBox1.Text == "")
            {
                MessageBox.Show("Preencha todos os campos!");
            }
            else if (comboBox1.Text == "")
            {
                MessageBox.Show("Preencha todos os campos!");
            }

            else
            {
                MessageBox.Show("Cadastro de Adotante salvo!");
            }

            int tipo = 0;

            if (comboBox1.SelectedIndex == 0)
                tipo = 1; 
            else if (comboBox1.SelectedIndex == 1)
                tipo = 2;
            else if (comboBox1.SelectedIndex == 2)
                tipo = 3;
            else if (comboBox1.SelectedIndex == 3)
                tipo = 4;
            else if (comboBox1.SelectedIndex == 4)
                tipo = 5;
            else if (comboBox1.SelectedIndex == 5)
                tipo = 6;
            else if (comboBox1.SelectedIndex == 6)
                tipo = 7;
            else if (comboBox1.SelectedIndex == 7)
                tipo = 8;
            else if (comboBox1.SelectedIndex == 8)
                tipo = 9;
            else if (comboBox1.SelectedIndex == 9)
                tipo = 10;
            else if (comboBox1.SelectedIndex == 10)
                tipo = 11;
            else if (comboBox1.SelectedIndex == 11)
                tipo = 12;
            else if (comboBox1.SelectedIndex == 12)
                tipo = 13;
            else if (comboBox1.SelectedIndex == 13)
                tipo = 14;
            else if (comboBox1.SelectedIndex == 14)
                tipo = 15;
            else if (comboBox1.SelectedIndex == 15)
                tipo = 16;
            else if (comboBox1.SelectedIndex == 16)
                tipo = 17;
            else if (comboBox1.SelectedIndex == 17)
                tipo = 18;
            else if (comboBox1.SelectedIndex == 18)
                tipo = 19;
            else if (comboBox1.SelectedIndex == 19)
                tipo = 20;
            else if (comboBox1.SelectedIndex == 20)
                tipo = 21;
            else if (comboBox1.SelectedIndex == 21)
                tipo = 22;
            else if (comboBox1.SelectedIndex == 22)
                tipo = 23;
            else if (comboBox1.SelectedIndex == 23)
                tipo = 24;
            else if (comboBox1.SelectedIndex == 24)
                tipo = 25;
            else if (comboBox1.SelectedIndex == 25)
                tipo = 26;
            else if (comboBox1.SelectedIndex == 26)
                tipo = 27;

            if (DAO_Conexao.CadAdotante(textBox1.Text, textBox2.Text, textBox3.Text, textBox4.Text, textBox5.Text, maskedTextBox1.Text, tipo))
                textBox2.ToString();
                MessageBox.Show("Cadastro Realizado");
            else
                MessageBox.Show("Erro");


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form6_Load(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}
